
import os

CUR_FPATH = os.path.abspath(__file__)
CUR_FDIR = os.path.dirname(CUR_FPATH)

os.chdir(CUR_FDIR)

req_freqs=["low"]

import threading
from proxy_env3 import ProxyEnv3


class Task: 

    def algo(self,algo_conf):
        self.env=ProxyEnv3()
        confs=[
            'mech_type',
            'scale_num',
            'scale_down_exec',
            'scale_up_exec',
            'sche',
            'instance_cache_policy'
        ]
        for i,conf in enumerate(confs[:5]):
            print("configuring ",conf," with ",algo_conf[i][0],"=",algo_conf[i][1])
            self.env.config["mech"][conf][algo_conf[i][0]]=algo_conf[i][1]
        for f in algo_conf[5]:
            print("configuring filter with ",list(f.keys())[0],"=",list(f.values())[0])
            filter_name=list(f.keys())[0]
            attr=f[filter_name]
            self.env.config["mech"]['filter'][filter_name]=attr
        for i,conf in enumerate(confs[5:]):
            print("configuring ",conf," with ",algo_conf[i+6][0],"=",algo_conf[i+6][1])
            self.env.config["mech"][conf][algo_conf[i+6][0]]=algo_conf[i+6][1]

        print("\n\n-------- testing: ",self.env.config["mech"])
        return self
        
    def config(self,config_cb):
        config_cb(self.env.config)
        return self
        
    def run(self):
        self.env.reset()
        
        state,score,stop,info=self.env.step(1)
        print(state,score,stop,info)
        return self

algos=[
    [['scale_sche_joint',''],["hpa",""],["default",""],["least_task",""],["pos","greedy"],[{'careful_down':''}],["no_evict",""]], 

    


    
    
    
]


for req_freq in req_freqs:    
    for algo in algos:
        def cb(config):
            config["request_freq"]=req_freq
        Task() \
            .algo(algo) \
            .config(cb) \
            .run()
