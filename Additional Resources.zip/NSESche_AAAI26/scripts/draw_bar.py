import os
CUR_FPATH = os.path.abspath(__file__)
CUR_FDIR = os.path.dirname(CUR_FPATH)
os.chdir(CUR_FDIR)

import requests
from pprint import pprint
import yaml
import re
import matplotlib.pyplot as plt
import numpy as np



    

    

        




        

import records_read
def get_record_filelist(drawconf):
    conf_2_files=records_read.group_by_conf_files()
    new={}
    for confstr in conf_2_files:
        conf=records_read.FlattenConfig(confstr)
        confjson=conf.json()
        
        nomatch_filter=False

        for drawfilter in drawconf['filter']:
            if drawfilter in confjson:
                if confjson[drawfilter]!=drawconf['filter'][drawfilter]:
                    nomatch_filter=True
                    break
        
        if nomatch_filter:
            continue


        nomatch_targets=True
        for target in drawconf['targets_alias']:
            nomatch_target=False
            for targetkey in target[0]:
                if targetkey not in confjson:
                    print("!!! invalid target alias with key",targetkey)
                    exit(1)
                if confjson[targetkey]!=target[0][targetkey]:
                    nomatch_target=True
                    break
            if not nomatch_target:
                nomatch_targets=False
                break
        if nomatch_targets:
            continue
        new[confstr]=conf_2_files[confstr]
    return new

def check_first_draw_group_match_avg_cnt(drawconf,conf_2_files):
    avg_cnt=drawconf['avg_cnt']
    if avg_cnt==0:
        print("!!! avg_cnt should not be 0")
        exit(1)
    
    first_group_k=drawconf['group']['by']
    first_group_v=drawconf['group']['types'][0]
    conf_2_files_only_first_group={}
    for confstr in conf_2_files:
        conf=records_read.FlattenConfig(confstr)
        if getattr(conf,first_group_k)==first_group_v:
            conf_2_files_only_first_group[confstr]=conf_2_files[confstr]

    for confstr in conf_2_files_only_first_group:
        if len(conf_2_files_only_first_group[confstr])<avg_cnt:
            print("!!!",confstr,"files cnt < avg_cnt")
            exit(1)

def get_each_group_prev_avg_cnt_file__compute_avg(drawconf,conf_2_files):
    avg_cnt=drawconf['avg_cnt']
    for confstr in conf_2_files:
        conf_2_files[confstr].sort()
    for confstr in conf_2_files:
        conf_2_files[confstr]=conf_2_files[confstr][:avg_cnt]
    conf_2_records={}
    for confstr in conf_2_files:
        file_records=[]
        for file in conf_2_files[confstr]:
            file_records.append(records_read.load_record_from_file(file))
        conf_2_records[confstr]=file_records
    conf_2_avg_record={}
    for confstr in conf_2_files:
        records=conf_2_records[confstr]
        avg_record=records_read.avg_records(records)
        conf_2_avg_record[confstr]=avg_record
    return conf_2_avg_record

def group_records(records,conf):
    group_by=conf['group']['by']
    group_types=conf['group']['types']
    groups=[{'group':group_type,'records':[]} for group_type in group_types]
    for record in records:
        attribute_value = getattr(record, group_by)
        groups[group_types.index(attribute_value)]['records'].append(record)
        

    return groups

def to_draw_meta(groups,conf):
    def groups_value(groups,valueconf):
        def spec_values(records):
            def spec_value(record):
                cost_per_req=record.cost_per_req
                time_per_req=record.time_per_req
                waitsche_time_per_req =record.waitsche_time_per_req 
                coldstart_time_per_req=record.coldstart_time_per_req
                datarecv_time_per_req =record.datarecv_time_per_req 
                exe_time_per_req=record.exe_time_per_req
                rps=record.rps
                fn_container_cnt=record.fn_container_cnt
                undone_req_cnt=record.undone_req_cnt
                transs=valueconf['trans']
                if isinstance(transs, list):
                    
                    return [eval(trans) for trans in transs]
                else:
                    return eval(transs)
            def alias(record):
                def match_args(args):
                    for argkey in args:
                        if getattr(record, argkey)!=args[argkey]:
                            return False
                    return True
                for target_alias in conf['targets_alias']:
                    if match_args(target_alias[0]):
                        return  target_alias[1]
                print("err!!!!")
                exit(1)
            return [[alias(record),spec_value(record)] for record in records]

        return [{
            'group': group['group'],
            'values': spec_values(group['records'])
        } for group in groups]
    
    values=conf['values']
    res=[
        {
            'value_y': valueconf['alias'],
            'groups':groups_value(groups,valueconf)
        } for valueconf in values
    ]

    if 'sort_by' in conf:
        sort_by_value_alias=conf['sort_by'][0].keys().__iter__().__next__()
        find_value_index=None
        for v in res:
            if v['value_y']==sort_by_value_alias:
                find_value_index=res.index(v)
        if find_value_index==None:
            print("err!!!!!, sort by value not found")
            exit(1)
        

        record_alias__values= res[find_value_index]['groups'][0]['values']
        
        def sort_access(target_alias):
            v=None
            for record_alias__value in record_alias__values:
                if record_alias__value[0]==target_alias[1]:
                    v=record_alias__value[1]
    
            if isinstance(v, list):
                return v[-1]
            return v
        conf['targets_alias']=sorted(conf['targets_alias'], key=sort_access)
        

    return res

def draw_with_draw_meta(drawmeta,conf):
    plotcnt=len(conf['values'])
    fig, plots = plt.subplots(1, plotcnt, figsize=(18, 6))

    plt.subplots_adjust(left=0.1, right=0.9, top=0.85, bottom=0.1)
    fig.set_size_inches(16, 4.5)
    bar_width = 0.05
    index = np.arange(len(conf['group']['types']))
    opacity = 0.4
    error_config = {'ecolor': '0.3'}
    patterns = ('x', '\\', '*', 'o', '.','O')
    colors=["#FC6B05","#FFB62B","#65B017","#99D8DB","#9BB7BB","#32CD32","#228B22","#8A2BE2"]
    
    plotidx=0
    for plot in plots:
        meta=drawmeta[plotidx]
        groups=meta['groups']
        plot.set_xticks(index)
        plot.set_xticklabels(conf['group']['type_alias'])

        plot.set_xlabel(conf['group']['alias'])
        plot.text(-1.26*(len(plots)-plotidx)+1.76, 1.05, meta['value_y'], ha='center', va='center', rotation=0, transform=plt.gca().transAxes)

        model_value={
            'v':None
        }
        def set_model_value(v):
            print("set_model_value",v)
            if isinstance(v, list):
                model_value['v']=[0 for _ in range(len(v))]
            else:
                model_value['v']=0
        value_idx=0
        for target_alias in conf['targets_alias']:
            values=[]
            value_alias=target_alias[1]

            
            def find_value_in_group(group,value_alias):
                for value in group['values']:
                    if value[0]==value_alias:
                        set_model_value(value[1])
                        return value[1]
                if model_value['v']==None:
                    print("err!!!!!, at least the first data source should be complete")
                    exit(1)
                return model_value['v']

            for group in groups:
                values.append(find_value_in_group(group,value_alias))
            
            
            bars_values=[]
            if isinstance(values[0], list):
                for value in values:
                    for i in range(1,len(value)):
                        value[i]=value[i-1]+value[i]

                sub_v_cnt=len(values[0])
                for i in range(sub_v_cnt):
                    bars_values.append([value[i] for value in values])
            else:
                bars_values.append(values)
            
            print(meta['value_y'],value_alias,bars_values)

            level=len(bars_values)
            def leveled_color(color,curlevel):
                def hex_to_rgb(hex_color):
                    hex_color = hex_color.lstrip('#')
                    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

                def rgb_to_hex(rgb_color):
                    return '#{:02x}{:02x}{:02x}'.format(*rgb_color)

                def adjust_brightness(hex_color, factor):
                    factor = max(min(factor, 2.0), 0.0)
                    rgb = hex_to_rgb(hex_color)
                    new_rgb = tuple(min(int(c * factor), 255) for c in rgb)
                    new_color = rgb_to_hex(new_rgb)
                    return new_color

                return adjust_brightness(color,1-0.15*curlevel)
            for barlevel,bar_values in reversed(list(enumerate(bars_values))):
                plot.bar(index+value_idx*bar_width,bar_values,bar_width,
                    color=(leveled_color(colors[value_idx%len(colors)],barlevel)),
                    label=value_alias,edgecolor="black"
                )
            value_idx+=1
        plotidx+=1

    
    plt.tight_layout()

    plt.subplots_adjust(top=0.9,right=0.6,wspace=0.25, hspace=0.25)
    
    plt.legend(loc='upper left', bbox_to_anchor=(1, 1), fontsize='xx-small')

    

    
    plt.show()
    
    
def pipeline():
    import sys
    if len(sys.argv)!=2:
        print("usage: python draw_bar.py <xxx.yaml>")
        exit(1)

    yamlfilepath=sys.argv[1]

    drawconf=yaml.safe_load(open(yamlfilepath, 'r'))

    print("\n\n get_record_filelist")
    conf_2_files=get_record_filelist(drawconf)

    print("\n\n check_first_draw_group_match_avg_cnt")
    check_first_draw_group_match_avg_cnt(drawconf,conf_2_files)

    print("\n\n get_each_group_prev_avg_cnt_file__compute_avg")
    records=get_each_group_prev_avg_cnt_file__compute_avg(drawconf,conf_2_files)

    print("\n\n flatten records")
    records=[records[confstr] for confstr in records]
    for record in records:
        print(record.configstr)
    
    print("\n\n group_records")
    groups=group_records(records,drawconf)
    
    print("\n\n to_draw_meta")
    drawmeta=to_draw_meta(groups,drawconf)
    
    print("\n\n")
    pprint(drawmeta)
    draw_with_draw_meta(drawmeta,drawconf)









pipeline()