"""Components for bandit algorithm."""

import numpy as np


class SimplifiedSlidingWindowUCB:
    """A simplified Sliding window UCB algorithm for non-starionary MABP.

    Used in Agent57.


    From paper "Agent57: Outperforming the Atari Human Benchmark"
    https://arxiv.org/pdf/2003.13350

    From original paper "On Upper-Confidence Bound Policies for Non-Stationary Bandit Problems":
    https://arxiv.org/abs/0805.3415

    """

    def __init__(
        self,
        num_arms: int,
        window_size: int,
        random_state: np.random.RandomState,
        beta: float = 1.0,
        epsilon: float = 0.5,
    ) -> None:

        self.num_arms = num_arms
        self.window_size = window_size
        self._random_state = random_state
        self._beta = beta
        self._epsilon = epsilon

        self._rewards = np.zeros((window_size, num_arms), dtype=np.float32)
        self._count = np.zeros((window_size, num_arms), dtype=np.int32)

        self.t = 0

    def update(self, current_arm: int, reward: float) -> None:
        """Update statistics."""
        index = self.t % self.window_size
        self._count[index, current_arm] = 1
        self._rewards[index, current_arm] = reward
        self.t += 1

    def sample(self) -> int:
        """Sample an arm to play."""
        if self.t < self.num_arms:
            a_t = self.t
        elif self._random_state.rand() <= self._epsilon:
            a_t = self._random_state.randint(0, self.num_arms)
        else:
            i = min(self.t, self.window_size)
            rewards_sum = np.sum(self._rewards[:i], axis=0)
            count = np.sum(self._count[:i], axis=0)

            mean = rewards_sum / (count + 1e-8)
            c = self._beta * np.sqrt(1 / count)
            ucb_result = mean + c

            a_t = np.argmax(ucb_result)
        return int(a_t)
