import os

CUR_FPATH = os.path.abspath(__file__)
CUR_FDIR = os.path.dirname(CUR_FPATH)

os.chdir(CUR_FDIR)

import requests
import numpy as np
import json
from pprint import pprint
from numpy import uint8
import random

OBSERVATION_N=80

SIM_URL="http://127.0.0.1:3000/"

ACTION_SPACE_LOW=0
ACTION_SPACE_HIGH=1

class Client:

    url=SIM_URL

    def request(self,api,data=None):
        if data is None:
            return requests.post(self.url+api)
        else:
            return requests.post(self.url+api,json=data)
    
    
Client().request("collect_seed_metrics")



        