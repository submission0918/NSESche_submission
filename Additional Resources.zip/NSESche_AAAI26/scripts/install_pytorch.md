1. install cuda

2. get install cmd from official page https://pytorch.org/get-started/locally/ with specific cuda version