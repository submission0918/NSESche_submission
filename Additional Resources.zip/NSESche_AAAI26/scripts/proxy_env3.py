import os

CUR_FPATH = os.path.abspath(__file__)
CUR_FDIR = os.path.dirname(CUR_FPATH)

os.chdir(CUR_FDIR)

import requests
import json
from pprint import pprint
import random

SIM_URL = "http://127.0.0.1:3000/"


import records_read



class ProxyEnv3:

    url = SIM_URL

    config = {
        "rand_seed": "",
        "request_freq": "low",

        "dag_type": "single",
        
        "cold_start": "high",
        "fn_type": "cpu",
        "no_log": False,
        "total_frame":1000,
        "mech": {}
    }

    env_id=""

    def __init__(self):
        with open("../serverless_sim/module_conf_es.json", "r") as f:
            self.config["mech"] = json.load(f)
        print(f"Config Templete {self.config}")
        print("\n\n")

    

    def __request(self, api, data=None):

        if data is None:
            res= requests.post(self.url+api)
        else:
            res= requests.post(self.url+api, json=data)


        return res

    def reset(self):
        res=self.__request("reset", {
            "config":self.config
        })
        self.env_id = res.json()['kernel']["env_id"]
        pyid=records_read.conf_str(self.config)
        rsid=self.env_id
        assert(pyid==rsid)
        return res.json()['kernel']

    def step(self, action):
        if self.env_id=="":
            print("env_id is empty, please reset the environment first.")
            print("\n\n")
            return
        
        res = self.__request("step", {"action": action, "env_id": self.env_id})
        return res.json()['kernel']

    def start_async_sim(self):
        def __start_sim():
            res = self.__request("step", {"action": 0, "env_id": self.env_id})
            return res.json()['kernel']
        import threading
        threading.Thread(target=__start_sim).start()
        

    def rl_step(self, action):
        if self.env_id=="":
            print("env_id is empty, please reset the environment first.")
            print("\n\n")
            return
        res = self.__request("rl_step", {"action": action})
        res = res.json()['kernel']
        return res['state'],res['score'],res['stop'],''