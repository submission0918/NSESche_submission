import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from matplotlib import rcParams

rcParams['font.family'] = 'Times New Roman'

trace_file = '../azurefunctions-dataset2019/invocations_per_function_md.anon.d01.csv'

with open(trace_file, 'r') as f:
    header = f.readline().strip().split(',')

minute_cols = header[4:]
usecols = header[:4] + minute_cols

print('Loading large file, please wait...')
df = pd.read_csv(trace_file, usecols=usecols)

minute_matrix = df[minute_cols].values
total_req_per_min = minute_matrix.sum(axis=0)

plt.figure(figsize=(8,3))
plt.hist(total_req_per_min, bins=100, color='royalblue', edgecolor='k', alpha=0.8)
plt.xlabel('Total Requests per Minute', fontsize=13)
plt.ylabel('Frequency (Minutes)', fontsize=13)
plt.title('Distribution of Total Requests per Minute (Azure Functions Trace)', fontsize=14)
plt.tight_layout()
plt.savefig('real_trace_total_req_per_min_hist.png', dpi=300)
plt.close()

concurrent_func_per_min = (minute_matrix > 0).sum(axis=0)

plt.figure(figsize=(8,3))
plt.hist(concurrent_func_per_min, bins=100, color='tomato', edgecolor='k', alpha=0.8)
plt.xlabel('Concurrent Function Types per Minute', fontsize=13)
plt.ylabel('Frequency (Minutes)', fontsize=13)
plt.title('Distribution of Concurrent Function Types per Minute (Azure Functions Trace)', fontsize=14)
plt.tight_layout()
plt.savefig('real_trace_concurrent_func_per_min_hist.png', dpi=300)
plt.close()

print('Analysis complete. Images saved as real_trace_total_req_per_min_hist.png and real_trace_concurrent_func_per_min_hist.png.') 