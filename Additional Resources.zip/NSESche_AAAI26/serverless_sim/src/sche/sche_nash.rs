use std::{
    collections::{HashMap, HashSet, VecDeque},
    env,
};
use crate::{
    fn_dag::{EnvFnExt, FnId},
    mechanism::{MechanismImpl, ScheCmd, SimEnvObserve},
    mechanism_thread::{MechCmdDistributor, MechScheduleOnceRes},
    node::{EnvNodeExt, NodeId},
    request::ReqId,
    sim_run::{schedule_helper, Scheduler},
    with_env_sub::{WithEnvCore, WithEnvHelp},
};
static LOG_NASH_NO_CONVERGE_MSG: &str = "Nash equilibrium did not converge within";
static LOG_SKIP_DUPLICATE_MSG: &str = "Skipping globally duplicate schedule request for fn";
fn get_ablation_type() -> String {
    env::var("NASH_ABLATION_TYPE").unwrap_or_else(|_| "full".to_string())
}
fn is_social_awareness_enabled() -> bool {
    let ablation_type = get_ablation_type();
    ablation_type != "no_social"
}
fn is_congestion_pricing_enabled() -> bool {
    let ablation_type = get_ablation_type();
    ablation_type != "no_pricing"
}
fn is_heterogeneity_modeling_enabled() -> bool {
    let ablation_type = get_ablation_type();
    ablation_type != "no_heterogeneity"
}
#[derive(Clone, Debug)]
pub struct AdaptiveHeterogeneitySpectrum {
    pub resource_intensity: f32,
    pub temporal_sensitivity: f32,
    pub complexity_factor: f32,
    pub network_dependency: f32,
    pub individuality_factor: f32,
}
#[derive(Clone, Debug)]
pub struct FunctionUtilityParams {
    pub heterogeneity_spectrum: AdaptiveHeterogeneitySpectrum,
    pub latency_weight: f32,
    pub cost_weight: f32,
    pub quality_weight: f32,
    pub latency_baseline: f32,
}
impl Default for FunctionUtilityParams {
    fn default() -> Self {
        Self {
            heterogeneity_spectrum: AdaptiveHeterogeneitySpectrum {
                resource_intensity: 0.5,
                temporal_sensitivity: 0.5,
                complexity_factor: 0.5,
                network_dependency: 0.5,
                individuality_factor: 0.5,
            },
            latency_weight: 35.0,       
            cost_weight: 0.012,         
            quality_weight: 15.0,       
            latency_baseline: 80.0,     
        }
    }
}
impl FunctionUtilityParams {
    pub fn from_azure_characteristics(
        cpu: f32,
        mem: f32, 
        cold_start_time: usize,
        dag_complexity: usize,
    ) -> Self {
        if !is_heterogeneity_modeling_enabled() {
            return Self::default_classification();
        }
        let resource_intensity = ((cpu.ln().max(0.1) + mem.ln().max(0.1)) / 12.0).tanh();
        let temporal_sensitivity = 1.0 / (1.0 + (cold_start_time as f32 / 250.0).powf(1.5));
        let complexity_factor = ((dag_complexity as f32).ln().max(0.1) / 1.5).tanh();
        let network_dependency = (complexity_factor * 0.8 + resource_intensity * 0.2).powf(1.2);
        let individuality_factor = ((cpu * 31.0 + mem * 37.0 + cold_start_time as f32 * 41.0) % 100.0) / 100.0;
        let latency_weight = 30.0 + 15.0 * temporal_sensitivity;
        let cost_weight = 0.010 + 0.008 * (1.0 - resource_intensity);
        let quality_weight = std::env::var("NASH_QUALITY_WEIGHT")
            .ok()
            .and_then(|s| s.parse::<f32>().ok())
            .unwrap_or(10.0 + 10.0 * complexity_factor); 
        let latency_baseline = 80.0 + 170.0 * (1.0 - temporal_sensitivity).powf(1.2);
        Self {
            heterogeneity_spectrum: AdaptiveHeterogeneitySpectrum {
                resource_intensity,
                temporal_sensitivity,
                complexity_factor,
                network_dependency,
                individuality_factor,
            },
            latency_weight,
            cost_weight,
            quality_weight,
            latency_baseline,
        }
    }
    pub fn default_classification() -> Self {
        Self {
            heterogeneity_spectrum: AdaptiveHeterogeneitySpectrum {
                resource_intensity: 0.5,
                temporal_sensitivity: 0.5,
                complexity_factor: 0.5,
                network_dependency: 0.5,
                individuality_factor: 0.5,
            },
            latency_weight: 35.0,
            cost_weight: 0.012,
            quality_weight: 15.0,
            latency_baseline: 80.0,
        }
    }
}
#[derive(Clone, Debug)]
pub struct OptimizationConfig {
    pub max_nash_iterations: u32,
    pub convergence_threshold: f32,
    pub social_gap_threshold: f32,
    pub price_feedback_rate: f32,
    pub load_history_capacity: usize,
}
impl Default for OptimizationConfig {
    fn default() -> Self {
        let price_feedback_rate = std::env::var("NASH_PRICE_FEEDBACK_RATE")
            .ok()
            .and_then(|s| s.parse::<f32>().ok())
            .unwrap_or(0.2); 
        Self {
            max_nash_iterations: 1,        
            convergence_threshold: 0.99,   
            social_gap_threshold: 0.99,    
            price_feedback_rate,
            load_history_capacity: 1,      
        }
    }
}
#[derive(Clone, Debug)]
pub struct LoadAdaptiveConfig {
    pub low_load_config: OptimizationConfig,
    pub middle_load_config: OptimizationConfig,
    pub high_load_config: OptimizationConfig,
}
impl Default for LoadAdaptiveConfig {
    fn default() -> Self {
        Self {
            low_load_config: OptimizationConfig {
                max_nash_iterations: 1,        
                convergence_threshold: 0.98,   
                social_gap_threshold: 0.98,    
                price_feedback_rate: 0.1,      
                load_history_capacity: 1,      
            },
            middle_load_config: OptimizationConfig {
                max_nash_iterations: 1,        
                convergence_threshold: 0.9995, 
                social_gap_threshold: 0.9995,  
                price_feedback_rate: 0.05,     
                load_history_capacity: 1,      
            },
            high_load_config: OptimizationConfig {
                max_nash_iterations: 1,        
                convergence_threshold: 0.9999, 
                social_gap_threshold: 0.9999,  
                price_feedback_rate: 0.03,     
                load_history_capacity: 1,      
            },
        }
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct ContinuousStrategy {
    pub urgency_level: f32,
    pub bid_aggressiveness: f32,
    pub delay_tolerance: f32,
}
impl ContinuousStrategy {
    pub fn default() -> Self {
        Self {
            urgency_level: 0.5,
            bid_aggressiveness: 0.7,    
            delay_tolerance: 0.1,       
        }
    }
    pub fn from_heterogeneity_spectrum(spectrum: &AdaptiveHeterogeneitySpectrum) -> Self {
        Self {
            urgency_level: spectrum.temporal_sensitivity,
            bid_aggressiveness: 0.6 + spectrum.resource_intensity * 0.2, 
            delay_tolerance: (1.0 - spectrum.temporal_sensitivity) * 0.15, 
        }
    }
    pub fn calculate_bid(&self, base_price: f32) -> f32 {
        base_price * (1.0 + self.bid_aggressiveness * self.urgency_level)
    }
    pub fn calculate_delay(&self) -> f32 {
        0.0  
    }
    pub fn calculate_strategy_utility(&self, base_price: f32) -> f32 {
        self.urgency_level * 100.0                          
            - self.bid_aggressiveness * base_price * 0.5    
            + self.delay_tolerance * 20.0                   
    }
}
pub struct StrategyGenerator;
impl StrategyGenerator {
    pub fn generate_strategy(spectrum: &AdaptiveHeterogeneitySpectrum) -> ContinuousStrategy {
        ContinuousStrategy::from_heterogeneity_spectrum(spectrum)
    }
    pub fn generate_strategy_candidates(spectrum: &AdaptiveHeterogeneitySpectrum) -> Vec<ContinuousStrategy> {
        let base_strategy = Self::generate_strategy(spectrum);
        let optimized_strategy = ContinuousStrategy {
            urgency_level: (base_strategy.urgency_level * 1.1).min(1.0),
            bid_aggressiveness: (base_strategy.bid_aggressiveness * 0.9).max(0.3),
            delay_tolerance: (base_strategy.delay_tolerance * 0.8).max(0.05),
        };
        vec![base_strategy, optimized_strategy]
    }
}
#[derive(Clone, Debug)]
pub struct NodeState {
    pub node_id: NodeId,
    pub cpu_utilization: f32,
    pub memory_utilization: f32,
    pub task_queue_length: usize,
    pub has_warm_container: bool,
    pub network_latency: f32,
    pub load_score: f32,
}
#[derive(Clone, Debug)]
pub struct PriceSignal {
    pub node_prices: HashMap<NodeId, f32>,
    pub global_load: f32,
    pub cold_start_premium: f32,
    pub network_congestion: f32,
}
#[derive(Clone, Debug)]
pub struct NashEquilibrium {
    pub strategy_distribution: HashMap<FnId, ContinuousStrategy>,
    pub convergence_score: f32,
    pub is_converged: bool,
    pub convergence_round: u32,
    pub agent_utilities: HashMap<FnId, f32>,
}
#[derive(Clone, Debug)]
pub struct ScheduleRequest {
    pub fn_id: FnId,
    pub req_id: ReqId,
    pub preferred_node: NodeId,
    pub chosen_strategy: ContinuousStrategy,
    pub bid_amount: f32,
    pub expected_utility: f32,
    pub delay_time: f32,
}
#[derive(Clone, Debug)]
pub struct FunctionAgent {
    pub fn_id: FnId,
    pub req_id: ReqId,
    pub utility_params: FunctionUtilityParams,
    pub current_strategy: ContinuousStrategy,
}
impl FunctionAgent {
    pub fn new(fn_id: FnId, req_id: ReqId) -> Self {
        Self {
            fn_id,
            req_id,
            utility_params: FunctionUtilityParams::default(),
            current_strategy: ContinuousStrategy::default(),
        }
    }
    pub fn make_social_aware_decision_with_count(
        &mut self, 
        current_signal: &PriceSignal, 
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        competing_functions: usize
    ) -> ScheduleRequest {
        if !is_social_awareness_enabled() {
            return self.make_basic_decision(current_signal, opponent_strategies);
        }
        let best_strategy = self.calculate_social_aware_best_response(
            opponent_strategies, 
            current_signal, 
            competing_functions
        );
        let (best_node, node_state) = self.find_best_node_for_strategy(&best_strategy, current_signal);
        let base_price = current_signal.node_prices.get(&best_node).unwrap_or(&1.0);
        let bid_amount = best_strategy.calculate_bid(*base_price);
        let expected_utility = self.calculate_social_aware_utility(
            &node_state, 
            *base_price, 
            current_signal.global_load, 
            competing_functions
        );
        self.current_strategy = best_strategy.clone();
        ScheduleRequest {
            fn_id: self.fn_id,
            req_id: self.req_id,
            preferred_node: best_node,
            chosen_strategy: best_strategy,
            bid_amount,
            expected_utility,
            delay_time: self.current_strategy.calculate_delay(),
        }
    }
    pub fn make_basic_decision(
        &mut self,
        current_signal: &PriceSignal,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>
    ) -> ScheduleRequest {
        let best_strategy = self.calculate_basic_best_response(
            opponent_strategies,
            current_signal
        );
        let (best_node, node_state) = self.find_best_node_for_strategy(&best_strategy, current_signal);
        let base_price = current_signal.node_prices.get(&best_node).unwrap_or(&1.0);
        let bid_amount = best_strategy.calculate_bid(*base_price);
        let expected_utility = self.calculate_utility(
            &node_state,
            *base_price,
            current_signal.global_load
        );
        self.current_strategy = best_strategy.clone();
        ScheduleRequest {
            fn_id: self.fn_id,
            req_id: self.req_id,
            preferred_node: best_node,
            chosen_strategy: best_strategy,
            bid_amount,
            expected_utility,
            delay_time: self.current_strategy.calculate_delay(),
        }
    }
    fn calculate_basic_best_response(
        &self,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal
    ) -> ContinuousStrategy {
        let candidates = StrategyGenerator::generate_strategy_candidates(&self.utility_params.heterogeneity_spectrum);
        let mut best_strategy = ContinuousStrategy::default();
        let mut max_utility = f32::NEG_INFINITY;
        for strategy in candidates {
            let expected_utility = self.evaluate_basic_strategy_utility(
                &strategy,
                opponent_strategies,
                signal
            );
            if expected_utility > max_utility {
                max_utility = expected_utility;
                best_strategy = strategy;
            }
        }
        best_strategy
    }
    fn evaluate_basic_strategy_utility(
        &self,
        strategy: &ContinuousStrategy,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal
    ) -> f32 {
        self.evaluate_base_strategy_utility(
            strategy,
            opponent_strategies,
            signal,
            false, 
            None
        )
    }
    fn calculate_social_aware_best_response(
        &self, 
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal,
        competing_functions: usize
    ) -> ContinuousStrategy {
        let candidates = StrategyGenerator::generate_strategy_candidates(&self.utility_params.heterogeneity_spectrum);
        let mut best_strategy = ContinuousStrategy::default();
        let mut max_utility = f32::NEG_INFINITY;
        for strategy in candidates {
            let expected_utility = self.evaluate_social_aware_strategy_utility(
                &strategy, 
                opponent_strategies, 
                signal, 
                competing_functions
            );
            if expected_utility > max_utility {
                max_utility = expected_utility;
                best_strategy = strategy;
            }
        }
        best_strategy
    }
    fn evaluate_base_strategy_utility(
        &self,
        strategy: &ContinuousStrategy,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal,
        use_social_aware: bool,
        competing_functions: Option<usize>
    ) -> f32 {
        let competition_level = self.calculate_strategy_competition(strategy, opponent_strategies);
        let (best_node, node_state) = self.find_best_node_for_strategy(strategy, signal);
        let base_utility = if use_social_aware && competing_functions.is_some() {
            self.calculate_social_aware_utility(
                &node_state, 
                *signal.node_prices.get(&best_node).unwrap_or(&1.0), 
                signal.global_load,
                competing_functions.unwrap()
            )
        } else {
            self.calculate_utility(
                &node_state, 
                *signal.node_prices.get(&best_node).unwrap_or(&1.0), 
                signal.global_load
            )
        };
        let competition_penalty = competition_level * 100.0;
        let strategy_bonus = strategy.calculate_strategy_utility(*signal.node_prices.get(&best_node).unwrap_or(&1.0));
        base_utility - competition_penalty + strategy_bonus
    }
    fn evaluate_social_aware_strategy_utility(
        &self,
        strategy: &ContinuousStrategy,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal,
        competing_functions: usize
    ) -> f32 {
        self.evaluate_base_strategy_utility(
            strategy, 
            opponent_strategies, 
            signal, 
            true, 
            Some(competing_functions)
        )
    }
    fn simulate_node_state(&self, node_id: NodeId, signal: &PriceSignal) -> NodeState {
        let base_price = signal.node_prices.get(&node_id).unwrap_or(&1.0);
        let cpu_utilization = (base_price - 0.5).max(0.0).min(0.95);
        let memory_utilization = cpu_utilization * 0.8;
        let has_warm_container = cpu_utilization < 0.7;
        NodeState {
            node_id,
            cpu_utilization,
            memory_utilization,
            task_queue_length: (cpu_utilization * 10.0) as usize,
            has_warm_container,
            network_latency: 5.0 + signal.network_congestion * 20.0,
            load_score: cpu_utilization,
        }
    }
    pub fn calculate_utility(&self, node_state: &NodeState, base_price: f32, system_load: f32) -> f32 {
        let spectrum = &self.utility_params.heterogeneity_spectrum;
        let base_benefit = 150.0 + 200.0 * spectrum.resource_intensity + 
                          150.0 * spectrum.temporal_sensitivity + 
                          100.0 * spectrum.complexity_factor;
        let actual_latency = self.estimate_actual_latency(node_state);
        let latency_utility = self.utility_params.latency_weight * 
            (self.utility_params.latency_baseline - actual_latency).max(0.0) * 
            (0.05 + 0.15 * spectrum.temporal_sensitivity);
        let cost_sensitivity = 1.0 + spectrum.resource_intensity * 2.0;
        let cost_utility = -self.utility_params.cost_weight * base_price * cost_sensitivity;
        let quality_score = (1.0 - node_state.cpu_utilization) * 0.5 + 
                           (1.0 - node_state.memory_utilization) * 0.3 +
                           (1.0 - system_load) * 0.2;
        let quality_multiplier = 30.0 + 40.0 * spectrum.complexity_factor + 30.0 * spectrum.network_dependency;
        let quality_utility = self.utility_params.quality_weight * quality_score * quality_multiplier;
        let cold_start_penalty = if node_state.has_warm_container { 
            0.0 
        } else { 
            (30.0 + 70.0 * spectrum.temporal_sensitivity) * (1.0 + spectrum.individuality_factor)
        };
        base_benefit + latency_utility + cost_utility + quality_utility - cold_start_penalty
    }
    pub fn calculate_social_aware_utility(&self, node_state: &NodeState, base_price: f32, system_load: f32, competing_functions: usize) -> f32 {
        let individual_utility = self.calculate_utility(node_state, base_price, system_load);
        let externality_cost = self.calculate_externality_impact(node_state, competing_functions);
        let social_contribution = self.calculate_social_contribution(node_state, system_load);
        individual_utility - externality_cost + social_contribution
    }
    fn calculate_externality_impact(&self, node_state: &NodeState, competing_functions: usize) -> f32 {
        let spectrum = &self.utility_params.heterogeneity_spectrum;
        let resource_pressure = (node_state.cpu_utilization + node_state.memory_utilization) / 2.0;
        let queue_impact = node_state.task_queue_length as f32 * 0.8;
        let externality_base = resource_pressure * competing_functions as f32 * queue_impact;
        externality_base * spectrum.resource_intensity * 100.0
    }
    fn calculate_social_contribution(&self, node_state: &NodeState, system_load: f32) -> f32 {
        let spectrum = &self.utility_params.heterogeneity_spectrum;
        let load_balancing_contribution = (1.0 - node_state.cpu_utilization) * 50.0;
        let system_relief_contribution = if system_load > 0.3 { 
            spectrum.temporal_sensitivity * 80.0 
        } else { 
            0.0 
        };
        load_balancing_contribution + system_relief_contribution
    }
    fn estimate_actual_latency(&self, node_state: &NodeState) -> f32 {
        let spectrum = &self.utility_params.heterogeneity_spectrum;
        let base_latency = 35.0 + 60.0 * spectrum.resource_intensity + 30.0 * spectrum.complexity_factor;
        let load_factor = 1.0 + (node_state.cpu_utilization + node_state.memory_utilization) * 0.4;
        let queue_factor = 1.0 + (node_state.task_queue_length as f32) * 0.03; 
        let network_adjustment = node_state.network_latency * (0.7 + spectrum.network_dependency * 0.3);
        base_latency * load_factor * queue_factor + network_adjustment
    }
    fn evaluate_strategy_utility(
        &self,
        strategy: &ContinuousStrategy,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>,
        signal: &PriceSignal
    ) -> f32 {
        self.evaluate_base_strategy_utility(strategy, opponent_strategies, signal, false, None)
    }
    fn calculate_strategy_competition(
        &self,
        strategy: &ContinuousStrategy,
        opponent_strategies: &HashMap<FnId, ContinuousStrategy>
    ) -> f32 {
        let mut competition_count = 0;
        for (_, opponent_strategy) in opponent_strategies {
            let similarity = 1.0 - ((strategy.urgency_level - opponent_strategy.urgency_level).abs() +
                                   (strategy.bid_aggressiveness - opponent_strategy.bid_aggressiveness).abs() / 2.0 +
                                   (strategy.delay_tolerance - opponent_strategy.delay_tolerance).abs()) / 3.0;
            if similarity > 0.7 {
                competition_count += 1;
            }
        }
        competition_count as f32 / opponent_strategies.len().max(1) as f32
    }
    fn find_best_node_for_strategy(
        &self,
        strategy: &ContinuousStrategy,
        signal: &PriceSignal
    ) -> (NodeId, NodeState) {
        let mut best_node = NodeId::default();
        let mut best_score = f32::NEG_INFINITY;
        let mut best_state = NodeState {
            node_id: NodeId::default(),
            cpu_utilization: 0.5,
            memory_utilization: 0.5,
            task_queue_length: 0,
            has_warm_container: false,
            network_latency: 10.0,
            load_score: 0.5,
        };
        for (&node_id, &base_price) in &signal.node_prices {
            let node_state = self.simulate_node_state(node_id, signal);
            let score = self.calculate_node_strategy_fit(&node_state, strategy, base_price);
            if score > best_score {
                best_score = score;
                best_node = node_id;
                best_state = node_state;
            }
        }
        (best_node, best_state)
    }
    fn calculate_node_strategy_fit(
        &self,
        node_state: &NodeState,
        strategy: &ContinuousStrategy,
        base_price: f32
    ) -> f32 {
        let resource_fit = (1.0 - node_state.cpu_utilization) * strategy.bid_aggressiveness;
        let latency_fit = (1.0 - node_state.network_latency / 100.0) * strategy.urgency_level;
        let cost_fit = (1.0 / base_price) * (2.0 - strategy.bid_aggressiveness);
        resource_fit + latency_fit + cost_fit
    }
}
pub struct ScheNashScheduler {
    config: OptimizationConfig,
    function_agents: HashMap<FnId, FunctionAgent>,
    current_price_signal: PriceSignal,
    node_states: HashMap<NodeId, NodeState>,
    fn_utility_configs: HashMap<FnId, FunctionUtilityParams>,
    nash_equilibrium: NashEquilibrium,
    load_feedback_history: VecDeque<f32>,
    scheduled_fn_req_pairs: HashSet<(FnId, ReqId)>,
}
impl ScheNashScheduler {
    pub fn new() -> Self {
        Self {
            config: OptimizationConfig::default(),
            function_agents: HashMap::new(),
            current_price_signal: PriceSignal {
                node_prices: HashMap::new(),
                global_load: 0.0,
                cold_start_premium: 1.2,
                network_congestion: 0.0,
            },
            node_states: HashMap::new(),
            fn_utility_configs: HashMap::new(),
            nash_equilibrium: NashEquilibrium {
                strategy_distribution: HashMap::new(),
                convergence_score: 0.0,
                is_converged: false,
                convergence_round: 0,
                agent_utilities: HashMap::new(),
            },
            load_feedback_history: VecDeque::with_capacity(OptimizationConfig::default().load_history_capacity),
            scheduled_fn_req_pairs: HashSet::new(),
        }
    }
    fn get_adaptive_config(&self, env: &SimEnvObserve) -> OptimizationConfig {
        let adaptive_config = LoadAdaptiveConfig::default();
        if env.help().config().request_freq_low() {
            adaptive_config.low_load_config
        } else if env.help().config().request_freq_middle() {
            adaptive_config.middle_load_config
        } else {
            adaptive_config.high_load_config
        }
    }
    fn broadcast_load_adaptive_price_signal(&mut self, env: &SimEnvObserve) {
        if !is_congestion_pricing_enabled() {
            self.broadcast_static_price_signal(env);
            return;
        }
        let current_load = self.calculate_system_load(env);
        let cold_start_rate = self.calculate_cold_start_rate(env);
        let network_congestion = self.calculate_network_congestion(env);
        let mut node_prices = HashMap::new();
        let use_simplified_pricing = env.help().config().request_freq_middle() || 
                                    !env.help().config().request_freq_low();
        for node in env.nodes().iter() {
            let node_cpu_util = node.cpu / node.rsc_limit.cpu;
            let node_mem_util = node.unready_mem() / node.rsc_limit.mem;
            let task_density = node.all_task_cnt() as f32 / 12.0;
            let base_price = if env.help().config().request_freq_low() {
                0.2      
            } else if env.help().config().request_freq_middle() {
                0.3      
            } else {
                0.4      
            };
            let final_price = if use_simplified_pricing {
                base_price * (1.0 + node_cpu_util * 2.0 + task_density * 1.5)
            } else {
                let load_factor = 1.0 + node_cpu_util * 4.0 + node_mem_util * 2.0;
                let congestion_factor = 1.0 + task_density * 3.0;
                let cold_start_factor = 1.0 + cold_start_rate * 2.0;
                let network_factor = 1.0 + network_congestion * 1.0;
                let social_cost_adjustment = self.calculate_social_cost_adjustment(node, env);
                base_price * load_factor * congestion_factor * cold_start_factor * network_factor + social_cost_adjustment
            };
            let price_cap = if env.help().config().request_freq_low() {
                2.0      
            } else {
                1.5      
            };
            node_prices.insert(node.node_id(), final_price.min(price_cap));
        }
        self.current_price_signal = PriceSignal {
            node_prices,
            global_load: current_load,
            cold_start_premium: 1.0 + cold_start_rate * 1.5,
            network_congestion,
        };
        self.load_feedback_history.push_back(current_load);
        let capacity = self.config.load_history_capacity;
        if self.load_feedback_history.len() > capacity {
            self.load_feedback_history.pop_front();
        }
    }
    fn broadcast_static_price_signal(&mut self, env: &SimEnvObserve) {
        let current_load = self.calculate_system_load(env);
        let mut node_prices = HashMap::new();
        let static_price = 0.3; 
        for node in env.nodes().iter() {
            node_prices.insert(node.node_id(), static_price);
        }
        self.current_price_signal = PriceSignal {
            node_prices,
            global_load: current_load,
            cold_start_premium: 1.0, 
            network_congestion: 0.0, 
        };
        self.load_feedback_history.push_back(current_load);
        let capacity = self.config.load_history_capacity;
        if self.load_feedback_history.len() > capacity {
            self.load_feedback_history.pop_front();
        }
    }
    fn calculate_social_cost_adjustment(&self, node: &crate::node::Node, env: &SimEnvObserve) -> f32 {
        let competing_requests = self.count_competing_requests_on_node(node, env);
        let resource_scarcity = (node.cpu / node.rsc_limit.cpu + node.unready_mem() / node.rsc_limit.mem) / 2.0;
        let externality_price = competing_requests as f32 * resource_scarcity * 0.5;
        let coordination_incentive = if resource_scarcity < 0.25 { -0.05 } else { 0.0 };
        externality_price + coordination_incentive
    }
    fn count_competing_requests_on_node(&self, node: &crate::node::Node, env: &SimEnvObserve) -> usize {
        let mut competing_count = 0;
        for (_, req) in env.core().requests().iter() {
            for (&_fn_id, &node_id) in req.fn_node.iter() {
                if node_id == node.node_id() {
                    competing_count += 1;
                }
            }
        }
        competing_count
    }
    fn solve_nash_equilibrium(&mut self) -> Vec<ScheduleRequest> {
        let agent_ids: Vec<FnId> = self.function_agents.keys().cloned().collect();
        let agent_count = agent_ids.len();
        let mut requests = Vec::with_capacity(agent_count);
        let mut round_strategies = HashMap::with_capacity(agent_count);
        let mut round_utilities = HashMap::with_capacity(agent_count);
        for round in 0..self.config.max_nash_iterations {
            round_strategies.clear(); 
            round_utilities.clear();
            for fn_id in &agent_ids {
                let opponent_strategies = self.get_opponent_strategies(*fn_id);
                let current_signal = self.current_price_signal.clone();
                let competing_functions = self.function_agents.len();
                if let Some(agent) = self.function_agents.get_mut(fn_id) {
                    let request = agent.make_social_aware_decision_with_count(&current_signal, &opponent_strategies, competing_functions);
                    round_strategies.insert(*fn_id, request.chosen_strategy.clone());
                    round_utilities.insert(*fn_id, request.expected_utility);
                    if round == self.config.max_nash_iterations - 1 {
                        requests.push(request);
                    }
                }
            }
            if round >= 1 {
                let nash_social_gap = self.calculate_nash_social_gap(&round_strategies);
                if nash_social_gap > 0.999 { 
                    self.adjust_price_for_social_optimality(nash_social_gap);
                }
                let stability = self.calculate_simple_stability(&round_strategies);
                if stability > self.config.convergence_threshold && nash_social_gap < self.config.social_gap_threshold {
                    log::debug!("纳什-社会均衡收敛：稳定性{:.2}, 偏差{:.3}", stability, nash_social_gap);
                    if round < self.config.max_nash_iterations - 1 {
                        requests.clear();
                        requests.reserve(agent_count); 
                        for fn_id in &agent_ids {
                            let opponent_strategies = self.get_opponent_strategies(*fn_id);
                        let current_signal = self.current_price_signal.clone();
                            let competing_functions = self.function_agents.len();
                            if let Some(agent) = self.function_agents.get_mut(fn_id) {
                                let request = agent.make_social_aware_decision_with_count(&current_signal, &opponent_strategies, competing_functions);
                            requests.push(request);
                        }
                    }
                }
                    self.nash_equilibrium.is_converged = true;
                    self.nash_equilibrium.convergence_round = round;
                break;
            }
            }
            self.nash_equilibrium.strategy_distribution = round_strategies.clone();
            self.nash_equilibrium.agent_utilities = round_utilities.clone();
        }
        if !self.nash_equilibrium.is_converged {
            log::debug!("{} {} rounds", LOG_NASH_NO_CONVERGE_MSG, self.config.max_nash_iterations);
        }
        requests
    }
    fn calculate_nash_social_gap(&self, strategies: &HashMap<FnId, ContinuousStrategy>) -> f32 {
        let mut individual_welfare = 0.0;
        let mut social_welfare = 0.0;
        for (fn_id, strategy) in strategies {
            if let Some(agent) = self.function_agents.get(fn_id) {
                individual_welfare += agent.utility_params.latency_weight + agent.utility_params.cost_weight;
                let coordination_score = if strategy.urgency_level > 0.7 {
                    0.9  
                } else if strategy.delay_tolerance > 0.7 {
                    1.2  
                } else {
                    1.1  
                };
                social_welfare += coordination_score;
            }
        }
        (individual_welfare - social_welfare).abs() / social_welfare.max(1.0)
    }
    fn adjust_price_for_social_optimality(&mut self, gap: f32) {
        let adjustment_factor = gap * 0.01; 
        for (_node_id, price) in self.current_price_signal.node_prices.iter_mut() {
            *price *= 1.0 + adjustment_factor;
            *price = price.min(0.05); 
        }
    }
    fn calculate_simple_stability(&self, current_strategies: &HashMap<FnId, ContinuousStrategy>) -> f32 {
        if self.nash_equilibrium.strategy_distribution.is_empty() {
            return 0.0;
        }
        let mut stable_count = 0;
        for (fn_id, strategy) in current_strategies {
            if let Some(previous_strategy) = self.nash_equilibrium.strategy_distribution.get(fn_id) {
            let similarity = 1.0 - ((strategy.urgency_level - previous_strategy.urgency_level).abs() +
                                   (strategy.bid_aggressiveness - previous_strategy.bid_aggressiveness).abs() +
                                   (strategy.delay_tolerance - previous_strategy.delay_tolerance).abs()) / 3.0;
                if similarity > 0.8 { 
                stable_count += 1;
                }
            }
        }
        stable_count as f32 / current_strategies.len() as f32
    }
    fn get_opponent_strategies(&self, exclude_fn_id: FnId) -> HashMap<FnId, ContinuousStrategy> {
        self.nash_equilibrium.strategy_distribution
            .iter()
            .filter(|(&fn_id, _)| fn_id != exclude_fn_id)
            .map(|(&fn_id, strategy)| (fn_id, strategy.clone()))
            .collect()
    }
    fn execute_nash_schedules_immediate(
        &mut self,
        requests: Vec<ScheduleRequest>,
        cmd_distributor: &MechCmdDistributor,
    ) {
        for request in requests {
            let key = (request.fn_id, request.req_id);
            if self.scheduled_fn_req_pairs.contains(&key) {
                log::debug!("{} {} req {}", LOG_SKIP_DUPLICATE_MSG, request.fn_id, request.req_id);
                continue;
            }
            self.scheduled_fn_req_pairs.insert(key);
            log::debug!("Executing immediate schedule: fn {} req {} -> node {}", 
                      request.fn_id, request.req_id, request.preferred_node);
            cmd_distributor
                .send(MechScheduleOnceRes::ScheCmd(ScheCmd {
                    nid: request.preferred_node,
                    reqid: request.req_id,
                    fnid: request.fn_id,
                    memlimit: None, 
                }))
                .unwrap_or_else(|e| log::warn!("Failed to send schedule command for fn {}: {:?}", request.fn_id, e));
        }
    }
    fn initialize_function_configs(&mut self, env: &SimEnvObserve) {
        let mut active_fn_ids = HashSet::new();
        for (_, req) in env.core().requests().iter() {
            let fns = schedule_helper::collect_task_to_sche(
                req,
                env,
                schedule_helper::CollectTaskConfig::All,
            );
            for fn_id in fns {
                active_fn_ids.insert(fn_id);
            }
        }
        for &fn_id in &active_fn_ids {
            if !self.fn_utility_configs.contains_key(&fn_id) {
                if fn_id < env.core().fns().len() {
                    let params = self.create_function_specific_params(fn_id, env);
                    self.fn_utility_configs.insert(fn_id, params);
                }
            }
        }
        self.fn_utility_configs.retain(|&fn_id, _| active_fn_ids.contains(&fn_id));
    }
    fn create_function_specific_params(&self, fn_id: FnId, env: &SimEnvObserve) -> FunctionUtilityParams {
        let func = env.func(fn_id);
        let dag_complexity = match env.core().dags().get(func.dag_id) {
            Some(dag) => {
                if dag.dag_inner.node_count() > 0 {
                    dag.dag_inner.node_count()
                } else {
                    5
                }
            },
            None => {
                3
            }
        };
        FunctionUtilityParams::from_azure_characteristics(
            func.cpu,
            func.mem,
            func.cold_start_time,
            dag_complexity,
        )
    }
    fn calculate_system_load(&self, env: &SimEnvObserve) -> f32 {
        let total_cpu_usage: f32 = env.nodes().iter()
            .map(|n| n.cpu)
            .sum();
        let total_cpu_capacity: f32 = env.nodes().iter()
            .map(|n| n.rsc_limit.cpu)
            .sum();
        if total_cpu_capacity > 0.0 {
            total_cpu_usage / total_cpu_capacity
        } else {
            0.0
        }
    }
    fn calculate_cold_start_rate(&self, env: &SimEnvObserve) -> f32 {
        let mut total_containers = 0;
        let mut cold_starts = 0;
        for node in env.nodes().iter() {
            for (fn_id, container) in node.fn_containers.borrow().iter() {
                total_containers += 1;
                if !container.is_running() {
                    cold_starts += 1;
                }
            }
        }
        if total_containers > 0 {
            cold_starts as f32 / total_containers as f32
        } else {
            0.0
        }
    }
    fn calculate_network_congestion(&self, env: &SimEnvObserve) -> f32 {
        let mut cross_node_requests = 0;
        let mut total_requests = 0;
        for (_, req) in env.core().requests().iter() {
            let nodes_used: HashSet<NodeId> = req.fn_node.values().cloned().collect();
            total_requests += req.fn_node.len();
            if nodes_used.len() > 1 {
                cross_node_requests += req.fn_node.len() - 1;
            }
        }
        if total_requests > 0 {
            cross_node_requests as f32 / total_requests as f32
        } else {
            0.0
        }
    }
    fn update_node_states(&mut self, env: &SimEnvObserve) {
        for node in env.nodes().iter() {
            let node_id = node.node_id();
            let cpu_utilization = node.cpu / node.rsc_limit.cpu;
            let memory_utilization = node.unready_mem() / node.rsc_limit.mem;
            let task_queue_length = node.all_task_cnt();
            let has_warm_container = node.fn_containers.borrow().values()
                .any(|container| container.is_running());
            let network_latency = 5.0 + (node_id as f32 * 1.0);
            let load_score = (cpu_utilization + memory_utilization) / 2.0;
            let node_state = NodeState {
                node_id,
                cpu_utilization,
                memory_utilization,
                task_queue_length,
                has_warm_container,
                network_latency,
                load_score,
            };
            self.node_states.insert(node_id, node_state);
        }
    }
    fn create_and_update_agents(&mut self, env: &SimEnvObserve) {
        let estimated_capacity = env.core().fns().len().max(16);
        let mut fn_req_mapping: HashMap<FnId, ReqId> = HashMap::with_capacity(estimated_capacity);
        for (_, req) in env.core().requests().iter() {
            let fns = schedule_helper::collect_task_to_sche(
                req,
                env,
                schedule_helper::CollectTaskConfig::All,
            );
            for fn_id in fns {
                if !fn_req_mapping.contains_key(&fn_id) {
                    fn_req_mapping.insert(fn_id, req.req_id);
                }
            }
        }
        self.function_agents.retain(|&fn_id, _| fn_req_mapping.contains_key(&fn_id));
        let active_req_ids: HashSet<ReqId> = fn_req_mapping.values().cloned().collect();
        self.scheduled_fn_req_pairs.retain(|(_, req_id)| active_req_ids.contains(req_id));
        for (fn_id, req_id) in fn_req_mapping {
            if !self.function_agents.contains_key(&fn_id) {
                let mut agent = FunctionAgent::new(fn_id, req_id);
                if let Some(params) = self.fn_utility_configs.get(&fn_id) {
                    agent.utility_params = params.clone();
                }
                self.function_agents.insert(fn_id, agent);
            } else {
                if let Some(agent) = self.function_agents.get_mut(&fn_id) {
                    if agent.req_id != req_id {
                        agent.req_id = req_id;
                    }
                }
            }
        }
    }
}
impl Scheduler for ScheNashScheduler {
    fn schedule_some(
        &mut self,
        env: &SimEnvObserve,
        mech: &MechanismImpl,
        cmd_distributor: &MechCmdDistributor,
    ) {
        if env.core().dags().is_empty() {
            return;
        }
        if env.core().fns().is_empty() || env.core().requests().is_empty() {
            return;
        }
        self.config = self.get_adaptive_config(env);
        self.initialize_function_configs(env);
        self.update_node_states(env);
        self.create_and_update_agents(env);
        if self.function_agents.is_empty() {
            return;
        }
        self.broadcast_load_adaptive_price_signal(env);
        let nash_requests = self.solve_nash_equilibrium();
        if nash_requests.is_empty() {
            return;
        }
        self.execute_nash_schedules_immediate(nash_requests.clone(), cmd_distributor);
        let total_agents = self.function_agents.len();
        let total_requests = nash_requests.len();
        let load_type = if env.help().config().request_freq_low() {
            "低负载"
        } else if env.help().config().request_freq_middle() {
            "中负载"  
        } else {
            "高负载"
        };
        let convergence_status = if self.nash_equilibrium.is_converged {
            format!("已收敛(轮次{})", self.nash_equilibrium.convergence_round)
        } else {
            "未收敛".to_string()
        };
        log::debug!(
            "纳什均衡调度({}) : {} 智能体, {} 决策, 收敛状态={}, 迭代轮次={}",
            load_type,
            total_agents,
            total_requests, 
            convergence_status,
            self.config.max_nash_iterations
        );
    }
}